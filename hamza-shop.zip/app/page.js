'use client';
import Image from 'next/image';
import { useState } from 'react';

const products = [
  {
    id: 1,
    name: { ar: 'تيشيرت رجالي', fr: 'T-shirt homme', en: "Men's T-shirt" },
    price: '120 MAD',
    image: '/tshirt.jpg',
  },
  {
    id: 2,
    name: { ar: 'سبادري كلاسيكي', fr: 'Chaussure classique', en: 'Classic shoes' },
    price: '250 MAD',
    image: '/shoes.jpg',
  },
];

const whatsapp = '212664981135';

const labels = {
  ar: 'المنتوجات',
  fr: 'Produits',
  en: 'Products',
};

export default function Home() {
  const [lang, setLang] = useState('ar');

  return (
    <main className="p-4">
      <div className="text-center">
        <Image src="/logo.png" alt="Hamza Shop" width={100} height={100} className="mx-auto" />
        <h1 className="text-3xl font-bold mt-2">Hamza Shop</h1>
        <div className="flex justify-center gap-2 mt-4">
          <button onClick={() => setLang('ar')}>🇲🇦</button>
          <button onClick={() => setLang('fr')}>🇫🇷</button>
          <button onClick={() => setLang('en')}>🇬🇧</button>
        </div>
      </div>
      <h2 className="text-xl font-semibold my-4">{labels[lang]}</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {products.map((p) => (
          <div key={p.id} className="bg-zinc-900 text-white rounded-xl p-4">
            <img src={p.image} alt={p.name[lang]} className="w-full h-40 object-cover rounded-lg mb-2" />
            <h3 className="text-lg font-bold">{p.name[lang]}</h3>
            <p>{p.price}</p>
            <a
              href={`https://wa.me/${whatsapp}?text=Bghit nstafsir 3la: ${encodeURIComponent(p.name[lang])}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block mt-2 bg-gold text-black px-4 py-1 rounded"
            >
              تواصل معانا
            </a>
          </div>
        ))}
      </div>
    </main>
  );
}
